
package model;

import java.net.URI;
import java.util.List;
import java.net.http.HttpClient;
import java.util.Collections;

public class ProductDetail{
    String product_id;
    String product_name; 
    String product_description;
    double quantity;
    double amount;
    int category_id;

    public ProductDetail(String product_id, String product_name, String product_description, double quantity, double amount,
     int category_id){
        this.product_id=product_id;
        this.product_name=product_name;
        this.product_description=product_description;
        this.quantity=quantity;
        this.amount=amount;
        this.category_id=category_id;

    }


}
