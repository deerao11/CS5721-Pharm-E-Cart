package Control;

import java.util.*;

public class PharmacyController implements IObserver {

    public void update(String orderId) {
        manageCancellation(orderId);
    }

    public void manageCatalog() {

    }

    public void manageInventory() {

    }

    public void manageCancellation(String OrderId) {

    }

}
