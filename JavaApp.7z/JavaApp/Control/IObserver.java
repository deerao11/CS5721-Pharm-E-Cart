package Control;

interface IObserver {
    public void update(String orderId);
}