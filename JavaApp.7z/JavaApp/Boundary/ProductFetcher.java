package Boundary;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.net.URI;
import java.util.List;
import java.net.http.HttpClient;
import java.util.Collections;


public class ProductFetcher {
    public List<ProductDetail> fetchdata() {
        try {
            var uri = URI.create("https://falconer2-71714182580c.herokuapp.com/get-product-catalog");
            //String jsonData = "{\"username\":\""+userId+"\",\"password\":\""+password+"-\"}";
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest
                    .newBuilder()
                    .uri(uri)
                    .header("accept", "application/json")
                    // .POST(HttpRequest.BodyPublishers.ofString(jsonData))
                    
                    .build();
            HttpResponse response = client.send(request, HttpResponse.BodyHandlers.ofString());
            System.out.println(response.statusCode());
            System.out.println(response.body());
    
            if (response.statusCode() == 200){
                ObjectMapper objm= new ObjectMapper();
                List<ProductDetail> productlist= objm.readValue(response.body(),new TypeReference<List<ProductDetail>>() {});
                return productlist;
                
            }else {
                System.err.println("Error: Unable to fetch data");
                return Collections.emptyList();
    
            
            }}catch (Exception ex){
              
            }  
    }
}